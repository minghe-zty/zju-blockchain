<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>注册处理</title>
</head>
<body>
    <?php
        // 检查是否为POST请求
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // 获取表单数据并进行基本的安全处理
            $id = isset($_POST['id']) ? htmlspecialchars(trim($_POST['id'])) : '';
            $name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
            $password = isset($_POST['password']) ? htmlspecialchars(trim($_POST['password'])) : '';
            $phone = isset($_POST['phone']) ? htmlspecialchars(trim($_POST['phone'])) : '';
            $inviteCode = isset($_POST['inviteCode']) ? htmlspecialchars(trim($_POST['inviteCode'])) : '';
            $ip = $_SERVER["REMOTE_ADDR"]; // 获取用户 IP 地址

            // 验证邀请码是否正确
            if ($inviteCode !== '123456') {
                echo "<script>alert('注册失败，邀请码无效！');</script>";
                echo "<script>location.href='register.html';</script>";
                exit;
            }

            // 验证表单数据是否填写完整
            if (empty($id) || empty($name) || empty($password) || empty($phone)) {
                echo "<script>alert('请填写所有字段');</script>";
                echo "<script>location.href='register.html';</script>";
                exit;
            }

            // 使用 debian-sys-maint 用户连接到数据库
            $mydbhost = 'localhost';  // 数据库主机
            $mydbuser = 'debian-sys-maint'; // 数据库用户名
            $mydbpass = 'FDeNWNbDkya6Z23j'; // 数据库密码
            $dbname = 'qqpass';     // 数据库名

            // 创建数据库连接
            $conn = mysqli_connect($mydbhost, $mydbuser, $mydbpass, $dbname);

            if (!$conn) {
                die("数据库连接失败: " . mysqli_error($conn));
            }

            // 插入数据的 SQL 语句
            $sql = "INSERT INTO information (id, name, password, phone, qauto, remember, lastlogin, readpolicy, IpAddress, showstatus, loginflag, showlogin, email)
                    VALUES ('$id', '$name', '$password', '$phone', '1', '1', '0', '1', '$ip', '离线', '2', '0', '$id@qq.com')";

            // 执行 SQL 语句
            $result = mysqli_query($conn, $sql);

            if (!$result) {
                die("数据插入失败: " . mysqli_error($conn));
            }

            // 关闭数据库连接
            mysqli_close($conn);

            // 注册成功，重定向到登录页面
            echo "<script>alert('注册成功！');</script>";
            echo "<script>location.href='welcome.html';</script>";
        } else {
            // 如果不是 POST 请求，则重定向回注册页面
            echo "<script>location.href='register.html';</script>";
        }
    ?>
</body>
</html>
