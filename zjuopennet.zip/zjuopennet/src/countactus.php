<?php
// 启用错误报告
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取表单数据
    $name = isset($_POST['name']) ? htmlspecialchars(trim($_POST['name'])) : '';
    $email = isset($_POST['email']) ? htmlspecialchars(trim($_POST['email'])) : '';
    $message = isset($_POST['message']) ? htmlspecialchars(trim($_POST['message'])) : '';

    // 验证数据
    if (!empty($name) && !empty($email) && !empty($message)) {
        // 使用 __DIR__ 获取文件的绝对路径
        $logFile = __DIR__ . "/contact_form_log.txt";
        
        // 准备日志数据
        $logData = date("Y-m-d H:i:s") . " - Name: " . $name . " - Email: " . $email . " - Message: " . $message . "\n";
        
        // 检查文件是否可写
        if (is_writable($logFile)) {
            // 将数据追加到文件中
            file_put_contents($logFile, $logData, FILE_APPEND);
            echo "感谢您的留言，我们会尽快与您联系。";
        } else {
            echo "无法写入日志文件，请检查文件权限。";
        }
    } else {
        echo "请填写所有字段。";
    }
} else {
    echo "无效的请求方式。";
}
