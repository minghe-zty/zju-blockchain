// server.js

const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const bcrypt = require('bcrypt'); // 用于密码哈希
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 数据库连接配置
const db = mysql.createConnection({
  host: 'localhost',
  user: 'zju_user',     // 替换为您的 MySQL 用户名
  password: 'secure_password', // 替换为您的 MySQL 密码
  database: 'zju_open_net' // 替换为您的数据库名称
});

db.connect((err) => {
  if (err) {
    console.error('数据库连接失败：' + err.stack);
    return;
  }
  console.log('已连接到数据库。');
});

// 注册接口
app.post('/register', (req, res) => {
  const { email, name, phone, password, inviteCode } = req.body;

  // 验证邀请码
  if (inviteCode !== '123456') {
    res.json({ success: false, message: '邀请码错误，无法注册。' });
    return;
  }

  // 对密码进行哈希处理
  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      res.json({ success: false, message: '密码处理错误' });
      return;
    }

    // 检查邮箱是否已被注册
    const checkEmailSql = 'SELECT * FROM users WHERE email = ?';
    db.query(checkEmailSql, [email], (err, results) => {
      if (err) {
        res.json({ success: false, message: '数据库查询错误' });
      } else if (results.length > 0) {
        res.json({ success: false, message: '该邮箱已被注册' });
      } else {
        // 插入新用户数据
        const insertUserSql = 'INSERT INTO users (email, name, phone, password) VALUES (?, ?, ?, ?)';
        db.query(insertUserSql, [email, name, phone, hashedPassword], (err, results) => {
          if (err) {
            res.json({ success: false, message: '注册失败，数据库错误' });
          } else {
            res.json({ success: true, message: '注册成功' });
          }
        });
      }
    });
  });
});

// 登录接口
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  const sql = 'SELECT * FROM users WHERE email = ?';
  db.query(sql, [email], (err, results) => {
    if (err) {
      res.json({ success: false, message: '数据库查询错误' });
    } else if (results.length > 0) {
      const user = results[0];
      // 比较密码哈希值
      bcrypt.compare(password, user.password, (err, isMatch) => {
        if (err) {
          res.json({ success: false, message: '密码比较错误' });
        } else if (isMatch) {
          res.json({ success: true, message: '登录成功' });
        } else {
          res.json({ success: false, message: '密码错误' });
        }
      });
    } else {
      res.json({ success: false, message: '用户不存在' });
    }
  });
});

// 启动服务器
app.listen(3000, () => {
  console.log('服务器已启动，监听端口3000。');
});
