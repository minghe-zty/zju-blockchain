App = {
  web3Provider: null,
  contracts: {},

  init: async function() {
    // Load persons data from person.json.
    $.getJSON('../person.json', function(data) {
      var personsRow = $('#personsRow');
      var personTemplate = $('#personTemplate');

      for (i = 0; i < data.length; i++) {
        personTemplate.find('.panel-title').text(data[i].name);
        personTemplate.find('img').attr('src', data[i].picture);
        personTemplate.find('.person-educational-background').text(data[i].educational_background);
        personTemplate.find('.person-age').text(data[i].age);
        personTemplate.find('.person-location').text(data[i].location);
        personTemplate.find('.btn-contact').attr('data-id', data[i].id);

        personsRow.append(personTemplate.html());
      }
    });

    return await App.initWeb3();
  },

  initWeb3: async function() {
    // Modern dapp browsers...
    if (window.ethereum) {
      App.web3Provider = window.ethereum;
      try {
        // Request account access
        await window.ethereum.request({ method: "eth_requestAccounts" });
      } catch (error) {
        // User denied account access...
        console.error("User denied account access");
      }
    } 
    // Legacy dapp browsers...
    else if (window.web3) {
      App.web3Provider = window.web3.currentProvider;
    } 
    // If no injected web3 instance is detected, fall back to Ganache
    else {
      App.web3Provider = new Web3.providers.HttpProvider("http://localhost:8545");
    }
    web3 = new Web3(App.web3Provider);

    return App.initContract();
  },

  initContract: function() {
    $.getJSON("Adoption.json", function(data) {
      // Instantiate contract with Truffle contract
      var AdoptionArtifact = data;
      App.contracts.Adoption = TruffleContract(AdoptionArtifact);

      // Set the provider for our contract
      App.contracts.Adoption.setProvider(App.web3Provider);

      // Use our contract to retrieve and mark the adopted persons
      return App.markAdopted();
    });

    return App.bindEvents();
  },

  bindEvents: function() {
    $(document).on('click', '.btn-contact', App.handleContact);
  },

  markAdopted: function() {
    var adoptionInstance;

    App.contracts.Adoption.deployed().then(function(instance) {
      adoptionInstance = instance;

      return adoptionInstance.getAdopters.call();
    }).then(function(adopters) {
      for (i = 0; i < adopters.length; i++) {
        if (adopters[i] !== "0x0000000000000000000000000000000000000000") {
          $(".panel-person").eq(i).find("button").text("Success").attr("disabled", true);
        }
      }
    }).catch(function(err) {
      console.log(err.message);
    });
  },

  handleContact: function(event) {
    event.preventDefault();

    var personId = parseInt($(event.target).data('id'));
    var adoptionInstance;

    // Get accounts to send transaction
    web3.eth.getAccounts(function (error, accounts) {
      if (error) {
        console.log(error);
      }

      var account = accounts[0];
      
      // Deploy the contract and execute adopt transaction
      App.contracts.Adoption.deployed()
        .then(function(instance) {
          adoptionInstance = instance;
          
          // Execute adopt function as a transaction
          return adoptionInstance.adopt(personId, { from: account });
        })
        .then(function(result) {
          // On successful transaction, fetch contact info and display
          $.getJSON('../person.json', function(data) {
            var person = data.find(p => p.id === personId);
            if (person) {
              var contactInfo = "Contact Info: " + person.number;  // Extract phone number
              $('#contactInfo').text(contactInfo);  // Display contact number
              $('#contactModal').modal('show');  // Show modal with contact info
            } else {
              console.log('Person not found');
            }
          }).fail(function() {
            console.log('Failed to load person data');
          });

          return App.markAdopted();
        })
        .catch(function(err) {
          console.log(err.message);
        });
    });
  },
};

$(function() {
  $(window).load(function() {
    App.init();
  });
});
