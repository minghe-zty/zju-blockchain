<?php
// 检查是否有数据被提交
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取数据
    $name = htmlspecialchars(trim($_POST["name"]));
    $email = htmlspecialchars(trim($_POST["email"]));
    $message = htmlspecialchars(trim($_POST["message"]));

    // 验证数据
    if (!empty($name) && !empty($email) && !empty($message)) {
        // 将数据保存到文本文件
        $logFile = "contact_form_log.txt";
        $logData = date("Y-m-d H:i:s") . " - Name: " . $name . " - Email: " . $email . " - Message: " . $message . "\n";
        file_put_contents($logFile, $logData, FILE_APPEND);

        // 发送确认邮件
        $to = $email;
        $subject = "感谢您的联系";
        $messageBody = "亲爱的 " . $name . "，\n\n我们已经收到您的留言。我们会尽快与您联系。\n\n留言内容：\n" . $message;
        $headers = "From: noreply@yourdomain.com" . "\r\n" .
            "Reply-To: noreply@yourdomain.com" . "\r\n" .
            "X-Mailer: PHP/" . phpversion();

        if (mail($to, $subject, $messageBody, $headers)) {
            echo "感谢您的留言，我们会尽快与您联系。";
        } else {
            echo "邮件发送失败，请稍后再试。";
        }
    } else {
        echo "请填写所有字段。";
    }
} else {
    echo "无效的请求。";
}
?>