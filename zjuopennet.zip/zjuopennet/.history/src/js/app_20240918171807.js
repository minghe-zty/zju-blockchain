App = {
  web3Provider: null,
  contracts: {},

  init: async function() {
    // Load pets.
    $.getJSON('../person.json', function(data) {
      var personsRow = $('#personsRow');
      var personTemplate = $('#personTemplate');

      for (i = 0; i < data.length; i ++) {
        personTemplate.find('.panel-title').text(data[i].name);
        personTemplate.find('img').attr('src', data[i].picture);
        personTemplate.find('.person-educational-background').text(data[i].educational_background);
        personTemplate.find('.person-age').text(data[i].age);
        personTemplate.find('.person-location').text(data[i].location);
        personTemplate.find('.btn-contact').attr('data-id', data[i].id);

        personsRow.append(personTemplate.html());
      }
    });

    return await App.initWeb3();
  },

  initWeb3: async function() {
    /*
     * Replace me...
     */
    $.getJSON("../person.json", function (data) {

      var personsRow = $("#personsRow");
      
      var personTemplate = $("#personTemplate");
      
      for (i = 0; i < data.length; i++) {
      
        personTemplate.find(".panel-title").text(data[i].name);
      
        personTemplate.find("img").attr("src", data[i].picture);
      
        personTemplate.find(".person-educational-background").text(data[i].educational_background);
      
        personTemplate.find(".person-age").text(data[i].age);

        personTemplate.find(".person-location").text(data[i].location);
      
        personTemplate.find(".btn-contact").attr("data-id", data[i].id);
      
        personsRow.append(personTemplate.html());
      
      }
      
      });
      
      return await App.initWeb3();
      
      },
      
      initWeb3: async function () {
      
      // Modern dapp browsers...
      
      if (window.ethereum) {
      
      App.web3Provider = window.ethereum;
      
      try {
      
      // Request account access
      
      await window.ethereum.request({ method: "eth_requestAccounts" });
      
      } catch (error) {
      
      // User denied account access...
      
      console.error("User denied account access");
      
      }
      
      }
      
      // Legacy dapp browsers...
      
      else if (window.web3) {
      
      App.web3Provider = window.web3.currentProvider;
      
      }
      
      // If no injected web3 instance is detected, fall back to Ganache
      
      else {
      
      App.web3Provider = new Web3.providers.HttpProvider(
      
      "http://localhost:8545"
      
      );
      
      }
      
      web3 = new Web3(App.web3Provider);
    return App.initContract();
  },

  initContract: function() {
    $.getJSON("Adoption.json", function (data) {

      // Get the necessary contract artifact file and instantiate it with @truffle/contract
      
      var AdoptionArtifact = data;
      
      App.contracts.Adoption = TruffleContract(AdoptionArtifact);
      
      // Set the provider for our contract
      
      App.contracts.Adoption.setProvider(App.web3Provider);
      
      // Use our contract to retrieve and mark the adopted pets
      
      return App.markAdopted();
      
      });

    return App.bindEvents();
  },

  bindEvents: function() {
    $(document).on('click', '.btn-contact', App.handleContact);
    $('#RegisterForm').on('submit',(e) => {
      e.preventDefault();
      let hash = {};
      let arg = ['email','password','password_confirm'];
      arg.forEach((name) => {
          let value = $('#RegisterForm').find(`[name= ${name}]`).val();
          hash[name] = value;
      })
      $('#RegisterForm').find('.error').each((index,span) => {
          $(span).text(''); //初始的错误提示为空
      })
      if(hash['email'] === ''){
          $('#RegisterForm').find('[name = "email"]').siblings('.error').text('请输入邮箱');
          return
      }
       if(hash['password'] === ''){
          $('#RegisterForm').find('[name = "password"]').siblings('.error').text('请输入密码');
          return
      }
      if(hash['password_confirm'] === ''){
          $('#RegisterForm').find('[name = "password_confirm"]').siblings('.error').text('请输入密码');
          return
      }
      if(hash['password'] !== hash['password_confirm'] ){
          $('#RegisterForm').find('[name = "password_confirm"]').siblings('.error').text('密码不匹配');
          return
      }
  },

  markAdopted: function() {
    var adoptionInstance;

    App.contracts.Adoption.deployed()

    .then(function (instance) {

    adoptionInstance = instance;

    return adoptionInstance.getAdopters.call();

    })

    .then(function (adopters) {

    for (i = 0; i < adopters.length; i++) {

    if (adopters[i] !== "0x0000000000000000000000000000000000000000") {

    $(".panel-person")

    .eq(i)

    .find("button")

    .text("Success")

    .attr("disabled", true);

    }

    }

    })

    .catch(function (err) {

    console.log(err.message);

    });
  },

  handleContact: function(event) {
    event.preventDefault();

    var personId = parseInt($(event.target).data('id'));
    var adoptionInstance;

    web3.eth.getAccounts(function (error, accounts) {
    
    if (error) {
    
    console.log(error);
    
    }
    
    var account = accounts[0];
    
    App.contracts.Adoption.deployed()
    
    .then(function (instance) {
    
    adoptionInstance = instance;
    
    // Execute adopt as a transaction by sending account
    
    return adoptionInstance.adopt(personId, { from: account });
    
    })
    
    /*.then(function (result) {
      alert("Contact successful! Here is the person's contact info: [Contact Info]"); 
      return App.markAdopted();
    })*/


    .then(function (result) {
      $('#contactInfo').text("Contact Info: [Contact Info]"); // 替换 [Contact Info] 为实际的联系方式
      $('#contactModal').modal('show'); // 使用Bootstrap的modal方法显示模态框
      return App.markAdopted();
  })
    
    .catch(function (err) {
    
    console.log(err.message);
    
    });
    
    });
    
    },
    
    };
    
    $(function () {
    
    $(window).load(function () {
    
    App.init();
    
    });
});
